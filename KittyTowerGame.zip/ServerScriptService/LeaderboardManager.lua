local Players = game:GetService("Players")
Players.PlayerAdded:Connect(function(player)
    local leaderstats = Instance.new("Folder")
    leaderstats.Name = "leaderstats"
    leaderstats.Parent = player
    local coins = Instance.new("IntValue"); coins.Name="Coins"; coins.Parent=leaderstats
    local tower = Instance.new("StringValue"); tower.Name="CurrentTower"; tower.Value="None"; tower.Parent=leaderstats
    local cp = Instance.new("IntValue"); cp.Name="CheckpointIndex"; cp.Parent=leaderstats
end)
