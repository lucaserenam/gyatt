local Towers = {}
Towers.List = {
    { Name = "Tower1", DisplayName = "Rant Tower - Easy" , StartHeight = 0 },
    { Name = "Tower2", DisplayName = "Rage Tower - Medium", StartHeight = 0 },
    { Name = "Tower3", DisplayName = "Chaos Tower - Hard"  , StartHeight = 0 },
}
Towers.CheckpointTag = "CheckpointIndex"
return Towers
