<img src="about me image.png">

# About Blank Cloak For Tabs
Puts a button on your site then when clicked it will send you to your requested link that is cloaked (useful for school)

Subscribe To IrwinTech On Youtube https://youtube.com/c/irwintech

Here is a useful site you can use to change the button css if you like https://getcssscan.com/css-buttons-examples
